﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorldSeriesHistory
{
    public class WorldSeries
    {
        public Team NationalLeagueTeam { get; set; }
        public Team AmericanLeagueTeam { get; set; }
    }
}
