# MLB World Series History - Design Guidelines

## Design Approach

**Selected System**: Material Design with sports content adaptation
**Rationale**: Information-dense historical content requires clear hierarchy, strong data organization, and proven interaction patterns for timelines, filters, and tables.

**Key Principles**:
- Data-forward presentation with visual breathing room
- Classic, timeless aesthetic honoring baseball tradition
- Progressive disclosure for dense statistical content
- Clear wayfinding through decades of history

---

## Typography

**Font Stack**: 
- Primary: 'Inter' (Google Fonts) - clean, highly legible for data
- Display: 'Playfair Display' - elegant serif for historical gravitas

**Hierarchy**:
- Hero headline: text-6xl/text-7xl, font-bold (Playfair Display)
- Section titles: text-4xl/text-5xl, font-semibold 
- Card titles: text-2xl, font-semibold
- Body text: text-base/text-lg, font-normal
- Stats/numbers: text-3xl/text-4xl, font-bold (Inter)
- Metadata: text-sm, font-medium

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16
- Component padding: p-6 to p-8
- Section spacing: py-16 to py-24
- Card gaps: gap-6 to gap-8
- Content max-width: max-w-7xl

---

## Page Structure

### Hero Section (60vh)
Full-width with dramatic baseball stadium imagery, centered content overlay with blurred-background button for main CTA

### Interactive Timeline Section
Horizontal scrollable timeline (1903-present) with decade markers, clickable years revealing championship details below

### Championship Statistics Dashboard
4-column grid (desktop) → 2-column (tablet) → 1-column (mobile)
- Total championships counter
- Most successful teams leaderboard
- Decades breakdown
- Recent champions

### Teams Section
3-column masonry grid of team cards:
- Team logo/name
- Championship count badge
- Years won (collapsible list)
- View details link

### Detailed Series Explorer
Data table with filters:
- Year, Teams, Winner, Series length (4-7 games)
- MVP information
- Search by team/year
- Sortable columns

### Notable Moments Gallery
2-column asymmetric layout featuring:
- Historic photos with captions
- Record achievements
- Legendary performances
- Pull quotes from memorable games

### Records & Milestones
Single-column max-w-4xl center-aligned content with categorized records in expandable accordions

---

## Component Library

**Navigation**:
- Sticky top nav with logo, main sections, search icon
- Dropdown for "Browse by Team" and "Browse by Decade"

**Cards**:
- Team cards: rounded-lg, elevated shadow, hover lift
- Year cards (timeline): compact, badge-style with championship indicator
- Moment cards: image-heavy with overlay text

**Data Display**:
- Tables: striped rows, sticky headers, responsive horizontal scroll
- Stats counters: large numbers with animated count-up on scroll into view
- Timeline: custom horizontal track with year markers and connection lines

**Forms**:
- Search bar: rounded-full with icon, prominent in nav
- Filters: checkbox groups in sidebar/dropdown
- Sort controls: dropdown select

**Interactive Elements**:
- Accordions for expandable content
- Modal overlays for detailed series information
- Tabs for switching between stats views (All-Time, By Decade, By Team)

---

## Images

**Hero Image**: 
Historic black and white photograph of classic World Series moment (packed stadium, celebration on field) - full-width, 60vh height with subtle gradient overlay for text readability

**Team Logos**:
Official MLB team logos throughout team cards and data tables

**Notable Moments**:
6-8 carefully curated historical photographs showing iconic World Series moments - varying sizes in asymmetric gallery layout

**Background Treatments**:
Subtle baseball diamond pattern or stitching texture as decorative element in footer or section dividers (low opacity, non-distracting)

---

## Animations

Minimal and purposeful:
- Timeline scroll reveal (fade-in)
- Stats counter animation on viewport entry
- Card hover elevation (subtle lift)
- Smooth transitions for accordion/tab switching

---

## Responsive Behavior

**Desktop (lg+)**: Multi-column grids, horizontal timeline, sidebar filters
**Tablet (md)**: 2-column layouts, collapsible filters
**Mobile (base)**: Single column, vertical timeline alternative, hamburger menu