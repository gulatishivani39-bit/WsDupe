import { useState, useMemo } from "react";
import { type WorldSeries } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SeriesExplorerProps {
  series: WorldSeries[];
  isLoading: boolean;
  searchQuery: string;
  selectedDecade: string | null;
}

export default function SeriesExplorer({
  series,
  isLoading,
  searchQuery,
  selectedDecade,
}: SeriesExplorerProps) {
  const [localSearch, setLocalSearch] = useState("");
  const [sortBy, setSortBy] = useState<"year-desc" | "year-asc">("year-desc");

  const effectiveSearch = searchQuery || localSearch;

  const filteredSeries = useMemo(() => {
    let filtered = [...series];

    if (effectiveSearch) {
      const query = effectiveSearch.toLowerCase();
      filtered = filtered.filter(
        (s) =>
          s.winner.toLowerCase().includes(query) ||
          s.loser.toLowerCase().includes(query) ||
          s.year.toString().includes(query) ||
          s.mvp?.toLowerCase().includes(query)
      );
    }

    if (selectedDecade) {
      const decade = parseInt(selectedDecade);
      filtered = filtered.filter((s) => s.year >= decade && s.year < decade + 10);
    }

    filtered.sort((a, b) => {
      if (sortBy === "year-desc") return b.year - a.year;
      return a.year - b.year;
    });

    return filtered;
  }, [series, effectiveSearch, selectedDecade, sortBy]);

  if (isLoading) {
    return (
      <section id="series" className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <Skeleton className="h-12 w-64 mx-auto mb-12" />
          <Skeleton className="h-96 w-full" />
        </div>
      </section>
    );
  }

  return (
    <section id="series" className="py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-4">
            Series Explorer
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Search and explore detailed information about every World Series
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by team, year, or MVP..."
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              className="pl-9"
              data-testid="input-series-search"
            />
          </div>
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
            <SelectTrigger className="w-full sm:w-48" data-testid="select-sort">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="year-desc">Newest First</SelectItem>
              <SelectItem value="year-asc">Oldest First</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {filteredSeries.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">
              No World Series found matching your search.
            </p>
          </div>
        ) : (
          <div className="border border-border rounded-md overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="font-semibold">Year</TableHead>
                    <TableHead className="font-semibold">Champion</TableHead>
                    <TableHead className="font-semibold">Runner-up</TableHead>
                    <TableHead className="font-semibold text-center">Series</TableHead>
                    <TableHead className="font-semibold">MVP</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSeries.map((s) => (
                    <TableRow key={s.id} data-testid={`row-series-${s.year}`}>
                      <TableCell className="font-medium">{s.year}</TableCell>
                      <TableCell>
                        <Badge variant="default">{s.winner}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{s.loser}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="text-sm font-medium">
                          {s.gamesWon}-{s.gamesLost}
                        </span>
                      </TableCell>
                      <TableCell>
                        {s.mvp ? (
                          <div className="text-sm">
                            <div className="font-medium">{s.mvp}</div>
                            {s.mvpTeam && (
                              <div className="text-muted-foreground text-xs">{s.mvpTeam}</div>
                            )}
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">N/A</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}

        <div className="mt-6 text-center text-sm text-muted-foreground">
          Showing {filteredSeries.length} of {series.length} World Series
        </div>
      </div>
    </section>
  );
}
