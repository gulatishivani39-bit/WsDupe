import { type NotableMoment } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles } from "lucide-react";

interface MomentsGalleryProps {
  moments: NotableMoment[];
  isLoading: boolean;
}

export default function MomentsGallery({ moments, isLoading }: MomentsGalleryProps) {
  if (isLoading) {
    return (
      <section id="moments" className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <Skeleton className="h-12 w-64 mx-auto mb-12" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  const sortedMoments = [...moments].sort((a, b) => b.year - a.year);

  return (
    <section id="moments" className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-4">
            Notable Moments
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Historic achievements and unforgettable performances from World Series history
          </p>
        </div>

        {sortedMoments.length === 0 ? (
          <div className="text-center py-12">
            <Sparkles className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">
              Notable moments will appear here
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {sortedMoments.map((moment, idx) => (
              <Card
                key={moment.id}
                className={`hover-elevate ${idx === 0 ? "md:col-span-2" : ""}`}
                data-testid={`card-moment-${idx}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <Badge variant="outline">{moment.year}</Badge>
                    <Badge variant="secondary" className="capitalize">
                      {moment.category}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-serif font-bold text-foreground">
                    {moment.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">
                    {moment.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
