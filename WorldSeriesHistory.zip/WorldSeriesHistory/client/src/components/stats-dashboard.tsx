import { type WorldSeries, type Team } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Users, Calendar, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface StatsDashboardProps {
  series: WorldSeries[];
  teams: Team[];
  isLoading: boolean;
}

export default function StatsDashboard({ series, teams, isLoading }: StatsDashboardProps) {
  if (isLoading) {
    return (
      <section id="statistics" className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  const totalChampionships = series.length;
  const topTeams = [...teams]
    .sort((a, b) => b.championships - a.championships)
    .slice(0, 3);

  const decadeCounts = series.reduce((acc, s) => {
    const decade = Math.floor(s.year / 10) * 10;
    acc[decade] = (acc[decade] || 0) + 1;
    return acc;
  }, {} as Record<number, number>);

  const mostActiveDecade = Object.entries(decadeCounts).sort(
    ([, a], [, b]) => b - a
  )[0];

  const recentChampions = [...series]
    .sort((a, b) => b.year - a.year)
    .slice(0, 3);

  return (
    <section id="statistics" className="py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-4">
            Championship Statistics
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Key numbers from over a century of World Series competition
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover-elevate" data-testid="card-total-series">
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Series
              </CardTitle>
              <Trophy className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalChampionships}</div>
              <p className="text-xs text-muted-foreground mt-1">
                1903 to {new Date().getFullYear()}
              </p>
            </CardContent>
          </Card>

          <Card className="hover-elevate" data-testid="card-top-teams">
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Most Championships
              </CardTitle>
              <Users className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {topTeams.map((team, idx) => (
                  <div
                    key={team.id}
                    className="flex items-center justify-between"
                    data-testid={`stat-top-team-${idx}`}
                  >
                    <span className="text-sm font-medium text-foreground truncate">
                      {idx + 1}. {team.name}
                    </span>
                    <Badge variant="secondary" className="ml-2 shrink-0">
                      {team.championships}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="hover-elevate" data-testid="card-most-active">
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Most Active Decade
              </CardTitle>
              <Calendar className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">
                {mostActiveDecade?.[0]}s
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {mostActiveDecade?.[1]} championships
              </p>
            </CardContent>
          </Card>

          <Card className="hover-elevate" data-testid="card-recent-winners">
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Recent Champions
              </CardTitle>
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {recentChampions.map((s, idx) => (
                  <div
                    key={s.id}
                    className="flex items-center justify-between"
                    data-testid={`stat-recent-${idx}`}
                  >
                    <span className="text-sm font-medium text-foreground truncate">
                      {s.year}
                    </span>
                    <Badge variant="outline" className="ml-2 shrink-0 text-xs">
                      {s.winner}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
