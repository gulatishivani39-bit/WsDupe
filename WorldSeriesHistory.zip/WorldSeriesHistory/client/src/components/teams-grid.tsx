import { type Team } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy } from "lucide-react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useState } from "react";
import { ChevronDown } from "lucide-react";

interface TeamsGridProps {
  teams: Team[];
  isLoading: boolean;
}

export default function TeamsGrid({ teams, isLoading }: TeamsGridProps) {
  const [openTeams, setOpenTeams] = useState<Set<string>>(new Set());

  const toggleTeam = (teamId: string) => {
    setOpenTeams((prev) => {
      const next = new Set(prev);
      if (next.has(teamId)) {
        next.delete(teamId);
      } else {
        next.add(teamId);
      }
      return next;
    });
  };

  if (isLoading) {
    return (
      <section id="teams" className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <Skeleton className="h-12 w-64 mx-auto mb-12" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  const sortedTeams = [...teams].sort((a, b) => b.championships - a.championships);

  return (
    <section id="teams" className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-4">
            Championship Teams
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore the complete championship records of all World Series winning teams
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedTeams.map((team) => {
            const isOpen = openTeams.has(team.id);
            return (
              <Card
                key={team.id}
                className="hover-elevate overflow-visible"
                data-testid={`card-team-${team.name.replace(/\s+/g, "-").toLowerCase()}`}
              >
                <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-4">
                  <CardTitle className="text-lg font-semibold text-foreground flex-1 truncate">
                    {team.name}
                  </CardTitle>
                  <Badge variant="default" className="shrink-0 ml-2">
                    <Trophy className="w-3 h-3 mr-1" />
                    {team.championships}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <Collapsible open={isOpen} onOpenChange={() => toggleTeam(team.id)}>
                    <CollapsibleTrigger
                      className="flex items-center justify-between w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
                      data-testid={`button-toggle-${team.name.replace(/\s+/g, "-").toLowerCase()}`}
                    >
                      <span>Championship years</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`}
                      />
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-4">
                      <div className="flex flex-wrap gap-2">
                        {team.yearsWon?.sort((a, b) => Number(b) - Number(a)).map((year) => (
                          <Badge
                            key={year}
                            variant="outline"
                            className="text-xs"
                            data-testid={`badge-year-${year}`}
                          >
                            {year}
                          </Badge>
                        ))}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
