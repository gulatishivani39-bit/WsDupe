import { useState, useRef, useEffect } from "react";
import { type WorldSeries } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TimelineProps {
  series: WorldSeries[];
  isLoading: boolean;
  onDecadeSelect: (decade: string | null) => void;
}

export default function Timeline({ series, isLoading, onDecadeSelect }: TimelineProps) {
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const decades = Array.from({ length: 13 }, (_, i) => 1900 + i * 10);

  const scrollToDecade = (direction: "left" | "right") => {
    if (scrollContainerRef.current) {
      const scrollAmount = 400;
      scrollContainerRef.current.scrollBy({
        left: direction === "right" ? scrollAmount : -scrollAmount,
        behavior: "smooth",
      });
    }
  };

  const selectedSeries = selectedYear ? series.find((s) => s.year === selectedYear) : null;

  if (isLoading) {
    return (
      <section id="timeline" className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <Skeleton className="h-12 w-64 mx-auto mb-12" />
          <Skeleton className="h-24 w-full" />
        </div>
      </section>
    );
  }

  return (
    <section id="timeline" className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-4">
            Championship Timeline
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Navigate through over a century of World Series history
          </p>
        </div>

        <div className="relative">
          <Button
            size="icon"
            variant="outline"
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-background shadow-lg"
            onClick={() => scrollToDecade("left")}
            data-testid="button-timeline-left"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <div
            ref={scrollContainerRef}
            className="overflow-x-auto scrollbar-hide scroll-smooth px-12"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            <div className="flex items-center gap-2 min-w-max py-4">
              {series
                .sort((a, b) => a.year - b.year)
                .map((s) => {
                  const isDecadeStart = s.year % 10 === 0;
                  const isSelected = selectedYear === s.year;

                  return (
                    <div key={s.year} className="flex flex-col items-center">
                      {isDecadeStart && (
                        <div className="text-xs font-semibold text-muted-foreground mb-2">
                          {s.year}s
                        </div>
                      )}
                      <button
                        onClick={() => setSelectedYear(isSelected ? null : s.year)}
                        className={`group relative ${isDecadeStart ? "mt-2" : ""}`}
                        data-testid={`button-year-${s.year}`}
                      >
                        <div
                          className={`w-3 h-3 rounded-full transition-all ${
                            isSelected
                              ? "bg-primary ring-4 ring-primary/30 scale-125"
                              : "bg-border hover:bg-primary/50 hover:scale-110"
                          }`}
                        />
                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                          <Badge variant="secondary" className="text-xs">
                            {s.year}
                          </Badge>
                        </div>
                      </button>
                    </div>
                  );
                })}
            </div>
          </div>

          <Button
            size="icon"
            variant="outline"
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-background shadow-lg"
            onClick={() => scrollToDecade("right")}
            data-testid="button-timeline-right"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {selectedSeries && (
          <Card className="mt-8 p-6 max-w-2xl mx-auto" data-testid={`card-series-${selectedSeries.year}`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-3">
                  <Trophy className="w-5 h-5 text-primary" />
                  <h3 className="font-serif font-bold text-2xl text-foreground">
                    {selectedSeries.year} World Series
                  </h3>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="default" className="font-semibold">
                      {selectedSeries.winner}
                    </Badge>
                    <span className="text-sm text-muted-foreground">defeated</span>
                    <Badge variant="secondary">{selectedSeries.loser}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Series: {selectedSeries.gamesWon}-{selectedSeries.gamesLost}
                  </p>
                  {selectedSeries.mvp && (
                    <p className="text-sm text-foreground">
                      <span className="font-semibold">MVP:</span> {selectedSeries.mvp}
                      {selectedSeries.mvpTeam && ` (${selectedSeries.mvpTeam})`}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>
    </section>
  );
}
