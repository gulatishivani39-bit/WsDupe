import { Button } from "@/components/ui/button";
import { Trophy, ChevronDown } from "lucide-react";
import heroImage from "@assets/generated_images/Classic_World_Series_stadium_scene_71b6212a.png";

export default function HeroSection() {
  const scrollToTimeline = () => {
    const element = document.getElementById("timeline");
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      window.scrollTo({
        top: elementPosition - offset,
        behavior: "smooth",
      });
    }
  };

  return (
    <section className="relative h-[60vh] min-h-[500px] flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/80" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 rounded-full bg-primary/20 backdrop-blur-sm flex items-center justify-center border-2 border-primary/30">
            <Trophy className="w-10 h-10 text-primary-foreground" />
          </div>
        </div>
        
        <h1 className="font-serif font-bold text-5xl md:text-7xl text-white mb-6 tracking-tight">
          The World Series
        </h1>
        
        <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
          Over a century of championship baseball. Explore the complete history of America's greatest sporting tradition from 1903 to the present day.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            size="lg"
            onClick={scrollToTimeline}
            className="bg-white/10 backdrop-blur-md border-2 border-white/20 text-white hover:bg-white/20 min-h-12 px-8"
            data-testid="button-explore-history"
          >
            Explore the History
            <ChevronDown className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-0 right-0 flex justify-center">
        <button
          onClick={scrollToTimeline}
          className="animate-bounce text-white/70 hover:text-white transition-colors"
          aria-label="Scroll to timeline"
          data-testid="button-scroll-indicator"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </div>
    </section>
  );
}
