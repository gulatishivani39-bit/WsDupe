import { type WorldSeries, type Team } from "@shared/schema";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Trophy, Award, Target } from "lucide-react";

interface RecordsSectionProps {
  series: WorldSeries[];
  teams: Team[];
}

export default function RecordsSection({ series, teams }: RecordsSectionProps) {
  const mostChampionships = [...teams].sort((a, b) => b.championships - a.championships)[0];
  
  const sweeps = series.filter((s) => s.gamesLost === 0);
  const longestSeries = series.filter((s) => s.gamesWon + s.gamesLost === 7);
  
  const mvpCounts = series.reduce((acc, s) => {
    if (s.mvp) {
      acc[s.mvp] = (acc[s.mvp] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);
  
  const multipleMVPs = Object.entries(mvpCounts)
    .filter(([, count]) => count > 1)
    .sort(([, a], [, b]) => b - a);

  const winStreaks = findWinStreaks(series);
  const longestWinStreak = winStreaks[0];

  return (
    <section id="records" className="py-16">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-4xl md:text-5xl text-foreground mb-4">
            Records & Milestones
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Remarkable achievements and historic records from World Series history
          </p>
        </div>

        <Accordion type="multiple" className="space-y-4" defaultValue={["team-records"]}>
          <AccordionItem value="team-records" className="border border-border rounded-md px-6">
            <AccordionTrigger
              className="hover:no-underline"
              data-testid="accordion-team-records"
            >
              <div className="flex items-center gap-3">
                <Trophy className="w-5 h-5 text-primary" />
                <span className="font-semibold text-lg">Team Records</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-4 pb-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium text-foreground mb-1">Most Championships</p>
                    <p className="text-sm text-muted-foreground">
                      All-time championship leader
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant="default" className="mb-1">
                      {mostChampionships?.name}
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      {mostChampionships?.championships} titles
                    </p>
                  </div>
                </div>

                {longestWinStreak && (
                  <div className="flex items-start justify-between gap-4 pt-4 border-t border-border">
                    <div>
                      <p className="font-medium text-foreground mb-1">Longest Win Streak</p>
                      <p className="text-sm text-muted-foreground">
                        Consecutive championships
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="default" className="mb-1">
                        {longestWinStreak.team}
                      </Badge>
                      <p className="text-sm text-muted-foreground">
                        {longestWinStreak.count} in a row ({longestWinStreak.years.join(", ")})
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="series-records" className="border border-border rounded-md px-6">
            <AccordionTrigger
              className="hover:no-underline"
              data-testid="accordion-series-records"
            >
              <div className="flex items-center gap-3">
                <Target className="w-5 h-5 text-primary" />
                <span className="font-semibold text-lg">Series Records</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-4 pb-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium text-foreground mb-1">Total Sweeps</p>
                    <p className="text-sm text-muted-foreground">
                      4-0 series victories
                    </p>
                  </div>
                  <Badge variant="secondary">{sweeps.length} series</Badge>
                </div>

                <div className="flex items-start justify-between gap-4 pt-4 border-t border-border">
                  <div>
                    <p className="font-medium text-foreground mb-1">Seven-Game Series</p>
                    <p className="text-sm text-muted-foreground">
                      Maximum length series
                    </p>
                  </div>
                  <Badge variant="secondary">{longestSeries.length} series</Badge>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="mvp-records" className="border border-border rounded-md px-6">
            <AccordionTrigger
              className="hover:no-underline"
              data-testid="accordion-mvp-records"
            >
              <div className="flex items-center gap-3">
                <Award className="w-5 h-5 text-primary" />
                <span className="font-semibold text-lg">MVP Records</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-4 pb-6">
              <div className="space-y-4">
                {multipleMVPs.length > 0 ? (
                  multipleMVPs.map(([player, count]) => (
                    <div
                      key={player}
                      className="flex items-start justify-between gap-4"
                      data-testid={`mvp-${player.replace(/\s+/g, "-").toLowerCase()}`}
                    >
                      <div>
                        <p className="font-medium text-foreground mb-1">{player}</p>
                        <p className="text-sm text-muted-foreground">Multiple MVP Awards</p>
                      </div>
                      <Badge variant="default">{count}× MVP</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No players with multiple MVP awards in the current dataset
                  </p>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </section>
  );
}

function findWinStreaks(series: WorldSeries[]) {
  const sortedSeries = [...series].sort((a, b) => a.year - b.year);
  const streaks: { team: string; count: number; years: number[] }[] = [];
  
  let currentStreak: { team: string; count: number; years: number[] } | null = null;
  
  for (const s of sortedSeries) {
    if (!currentStreak || currentStreak.team !== s.winner) {
      if (currentStreak) streaks.push(currentStreak);
      currentStreak = { team: s.winner, count: 1, years: [s.year] };
    } else if (s.year === currentStreak.years[currentStreak.years.length - 1] + 1) {
      currentStreak.count++;
      currentStreak.years.push(s.year);
    } else {
      streaks.push(currentStreak);
      currentStreak = { team: s.winner, count: 1, years: [s.year] };
    }
  }
  
  if (currentStreak) streaks.push(currentStreak);
  
  return streaks.filter((s) => s.count > 1).sort((a, b) => b.count - a.count);
}
