import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type WorldSeries, type Team, type NotableMoment } from "@shared/schema";
import HeroSection from "@/components/hero-section";
import Timeline from "@/components/timeline";
import StatsDashboard from "@/components/stats-dashboard";
import TeamsGrid from "@/components/teams-grid";
import SeriesExplorer from "@/components/series-explorer";
import MomentsGallery from "@/components/moments-gallery";
import RecordsSection from "@/components/records-section";
import Navigation from "@/components/navigation";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDecade, setSelectedDecade] = useState<string | null>(null);

  const { data: seriesData, isLoading: seriesLoading } = useQuery<WorldSeries[]>({
    queryKey: ["/api/world-series"],
  });

  const { data: teamsData, isLoading: teamsLoading } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const { data: momentsData, isLoading: momentsLoading } = useQuery<NotableMoment[]>({
    queryKey: ["/api/moments"],
  });

  return (
    <div className="min-h-screen bg-background">
      <Navigation onSearch={setSearchQuery} />
      
      <HeroSection />
      
      <main className="relative">
        <Timeline 
          series={seriesData || []} 
          isLoading={seriesLoading}
          onDecadeSelect={setSelectedDecade}
        />
        
        <StatsDashboard 
          series={seriesData || []} 
          teams={teamsData || []}
          isLoading={seriesLoading || teamsLoading}
        />
        
        <TeamsGrid 
          teams={teamsData || []} 
          isLoading={teamsLoading}
        />
        
        <SeriesExplorer 
          series={seriesData || []} 
          isLoading={seriesLoading}
          searchQuery={searchQuery}
          selectedDecade={selectedDecade}
        />
        
        <MomentsGallery 
          moments={momentsData || []} 
          isLoading={momentsLoading}
        />
        
        <RecordsSection 
          series={seriesData || []}
          teams={teamsData || []}
        />
      </main>
      
      <footer className="bg-card border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-muted-foreground text-sm">
            MLB World Series History &copy; {new Date().getFullYear()} • A comprehensive archive of championship baseball
          </p>
        </div>
      </footer>
    </div>
  );
}
