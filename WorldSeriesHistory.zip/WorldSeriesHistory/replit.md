# MLB World Series History - Project Documentation

## Overview

This is a web application that showcases the complete history of Major League Baseball World Series championships from 1903 to the present. The application provides an interactive timeline, comprehensive statistics, team records, notable moments, and detailed series information through a clean, data-forward interface inspired by Material Design principles adapted for sports content.

The application emphasizes historical baseball data presentation with a classic, timeless aesthetic that honors baseball tradition while providing modern web interaction patterns for exploring decades of championship history.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state and data fetching
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens

**Design System**:
- Custom theme based on Material Design principles adapted for sports content
- Typography: Inter (data/UI) and Playfair Display (headings/historical gravitas)
- Color scheme: Neutral base with green primary accent
- Component variants using class-variance-authority for consistent styling patterns

**Component Structure**:
- Page components in `client/src/pages/`
- Reusable feature components in `client/src/components/`
- UI primitives in `client/src/components/ui/` (Shadcn/ui components)
- Custom hooks in `client/src/hooks/`

### Backend Architecture

**Runtime**: Node.js with Express
- **API Pattern**: RESTful JSON API endpoints
- **Data Storage**: In-memory storage (MemStorage class) with interfaces for future database integration
- **Development Server**: Vite dev server with middleware mode for HMR

**API Endpoints**:
- `GET /api/world-series` - Returns all World Series championship data
- `GET /api/teams` - Returns team championship statistics
- `GET /api/moments` - Returns notable moments from World Series history

**Storage Architecture**:
- Interface-based storage pattern (`IStorage`) for abstraction
- Current implementation: `MemStorage` - in-memory Map-based storage with seed data
- Schema definitions using Drizzle ORM types for future database migration
- Prepared for PostgreSQL integration (Drizzle config present but not actively used)

### Build & Development

**Build Tool**: Vite
- **Development**: HMR with proxy to Express backend
- **Production**: Static asset compilation with SSR-ready Express server
- **Asset Resolution**: Custom path aliases (@/, @shared/, @assets/)

**TypeScript Configuration**:
- Strict mode enabled
- ESNext module system
- Path aliases for clean imports
- Shared types between frontend and backend

### Data Model

**Core Entities** (defined in `shared/schema.ts`):

1. **WorldSeries**
   - Year, winner, loser, game counts
   - MVP information
   - Comprehensive series outcome data

2. **Teams**
   - Team name, total championships
   - Array of years won
   - Aggregate statistics

3. **NotableMoments**
   - Year, title, description
   - Category classification
   - Historical highlights

**Validation**: Zod schemas derived from Drizzle ORM table definitions for type-safe data handling.

## External Dependencies

### Core Framework Dependencies
- **React**: UI rendering and component architecture
- **Express**: Backend HTTP server
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the stack

### UI Component Libraries
- **Radix UI**: Headless accessible UI primitives (accordion, dialog, dropdown, select, etc.)
- **Shadcn/ui**: Pre-styled component library built on Radix
- **Lucide React**: Icon library
- **Tailwind CSS**: Utility-first styling framework

### Data & State Management
- **TanStack Query (React Query)**: Server state management and caching
- **Wouter**: Lightweight client-side routing
- **React Hook Form**: Form state management
- **Zod**: Runtime schema validation

### Database & ORM (Prepared but not active)
- **Drizzle ORM**: Type-safe SQL query builder
- **@neondatabase/serverless**: PostgreSQL driver
- **drizzle-zod**: Zod schema generation from Drizzle tables

The application is architected to migrate from in-memory storage to PostgreSQL by implementing a new storage class that conforms to the `IStorage` interface. Database schema and configuration are already defined for this future transition.

### Development Tools
- **Replit-specific plugins**: Vite plugins for Replit IDE integration
- **PostCSS**: CSS processing with Tailwind
- **ESBuild**: Production bundling for server code

### Styling & Design
- **class-variance-authority**: Component variant management
- **clsx** & **tailwind-merge**: Conditional class composition
- **date-fns**: Date formatting utilities