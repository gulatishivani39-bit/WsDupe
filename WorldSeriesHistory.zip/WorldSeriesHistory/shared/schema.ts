import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const worldSeries = pgTable("world_series", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  year: integer("year").notNull().unique(),
  winner: text("winner").notNull(),
  loser: text("loser").notNull(),
  gamesWon: integer("games_won").notNull(),
  gamesLost: integer("games_lost").notNull(),
  mvp: text("mvp"),
  mvpTeam: text("mvp_team"),
});

export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  championships: integer("championships").notNull().default(0),
  yearsWon: text("years_won").array(),
});

export const notableMoments = pgTable("notable_moments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  year: integer("year").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
});

export const insertWorldSeriesSchema = createInsertSchema(worldSeries).omit({
  id: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
});

export const insertNotableMomentSchema = createInsertSchema(notableMoments).omit({
  id: true,
});

export type InsertWorldSeries = z.infer<typeof insertWorldSeriesSchema>;
export type WorldSeries = typeof worldSeries.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;
export type InsertNotableMoment = z.infer<typeof insertNotableMomentSchema>;
export type NotableMoment = typeof notableMoments.$inferSelect;
