import {
  type WorldSeries,
  type InsertWorldSeries,
  type Team,
  type InsertTeam,
  type NotableMoment,
  type InsertNotableMoment,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getAllWorldSeries(): Promise<WorldSeries[]>;
  getAllTeams(): Promise<Team[]>;
  getAllNotableMoments(): Promise<NotableMoment[]>;
}

export class MemStorage implements IStorage {
  private worldSeries: Map<string, WorldSeries>;
  private teams: Map<string, Team>;
  private notableMoments: Map<string, NotableMoment>;

  constructor() {
    this.worldSeries = new Map();
    this.teams = new Map();
    this.notableMoments = new Map();
    this.seedData();
  }

  private seedData() {
    const seriesData: Omit<WorldSeries, "id">[] = [
      { year: 2024, winner: "Los Angeles Dodgers", loser: "New York Yankees", gamesWon: 4, gamesLost: 1, mvp: "Freddie Freeman", mvpTeam: "Los Angeles Dodgers" },
      { year: 2023, winner: "Texas Rangers", loser: "Arizona Diamondbacks", gamesWon: 4, gamesLost: 1, mvp: "Corey Seager", mvpTeam: "Texas Rangers" },
      { year: 2022, winner: "Houston Astros", loser: "Philadelphia Phillies", gamesWon: 4, gamesLost: 2, mvp: "Jeremy Peña", mvpTeam: "Houston Astros" },
      { year: 2021, winner: "Atlanta Braves", loser: "Houston Astros", gamesWon: 4, gamesLost: 2, mvp: "Jorge Soler", mvpTeam: "Atlanta Braves" },
      { year: 2020, winner: "Los Angeles Dodgers", loser: "Tampa Bay Rays", gamesWon: 4, gamesLost: 2, mvp: "Corey Seager", mvpTeam: "Los Angeles Dodgers" },
      { year: 2019, winner: "Washington Nationals", loser: "Houston Astros", gamesWon: 4, gamesLost: 3, mvp: "Stephen Strasburg", mvpTeam: "Washington Nationals" },
      { year: 2018, winner: "Boston Red Sox", loser: "Los Angeles Dodgers", gamesWon: 4, gamesLost: 1, mvp: "Steve Pearce", mvpTeam: "Boston Red Sox" },
      { year: 2017, winner: "Houston Astros", loser: "Los Angeles Dodgers", gamesWon: 4, gamesLost: 3, mvp: "George Springer", mvpTeam: "Houston Astros" },
      { year: 2016, winner: "Chicago Cubs", loser: "Cleveland Indians", gamesWon: 4, gamesLost: 3, mvp: "Ben Zobrist", mvpTeam: "Chicago Cubs" },
      { year: 2015, winner: "Kansas City Royals", loser: "New York Mets", gamesWon: 4, gamesLost: 1, mvp: "Salvador Pérez", mvpTeam: "Kansas City Royals" },
      { year: 2014, winner: "San Francisco Giants", loser: "Kansas City Royals", gamesWon: 4, gamesLost: 3, mvp: "Madison Bumgarner", mvpTeam: "San Francisco Giants" },
      { year: 2013, winner: "Boston Red Sox", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 2, mvp: "David Ortiz", mvpTeam: "Boston Red Sox" },
      { year: 2012, winner: "San Francisco Giants", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 0, mvp: "Pablo Sandoval", mvpTeam: "San Francisco Giants" },
      { year: 2011, winner: "St. Louis Cardinals", loser: "Texas Rangers", gamesWon: 4, gamesLost: 3, mvp: "David Freese", mvpTeam: "St. Louis Cardinals" },
      { year: 2010, winner: "San Francisco Giants", loser: "Texas Rangers", gamesWon: 4, gamesLost: 1, mvp: "Edgar Rentería", mvpTeam: "San Francisco Giants" },
      { year: 2009, winner: "New York Yankees", loser: "Philadelphia Phillies", gamesWon: 4, gamesLost: 2, mvp: "Hideki Matsui", mvpTeam: "New York Yankees" },
      { year: 2008, winner: "Philadelphia Phillies", loser: "Tampa Bay Rays", gamesWon: 4, gamesLost: 1, mvp: "Cole Hamels", mvpTeam: "Philadelphia Phillies" },
      { year: 2007, winner: "Boston Red Sox", loser: "Colorado Rockies", gamesWon: 4, gamesLost: 0, mvp: "Mike Lowell", mvpTeam: "Boston Red Sox" },
      { year: 2006, winner: "St. Louis Cardinals", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 1, mvp: "David Eckstein", mvpTeam: "St. Louis Cardinals" },
      { year: 2005, winner: "Chicago White Sox", loser: "Houston Astros", gamesWon: 4, gamesLost: 0, mvp: "Jermaine Dye", mvpTeam: "Chicago White Sox" },
      { year: 2004, winner: "Boston Red Sox", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 0, mvp: "Manny Ramírez", mvpTeam: "Boston Red Sox" },
      { year: 2003, winner: "Florida Marlins", loser: "New York Yankees", gamesWon: 4, gamesLost: 2, mvp: "Josh Beckett", mvpTeam: "Florida Marlins" },
      { year: 2002, winner: "Anaheim Angels", loser: "San Francisco Giants", gamesWon: 4, gamesLost: 3, mvp: "Troy Glaus", mvpTeam: "Anaheim Angels" },
      { year: 2001, winner: "Arizona Diamondbacks", loser: "New York Yankees", gamesWon: 4, gamesLost: 3, mvp: "Randy Johnson", mvpTeam: "Arizona Diamondbacks" },
      { year: 2000, winner: "New York Yankees", loser: "New York Mets", gamesWon: 4, gamesLost: 1, mvp: "Derek Jeter", mvpTeam: "New York Yankees" },
      { year: 1999, winner: "New York Yankees", loser: "Atlanta Braves", gamesWon: 4, gamesLost: 0, mvp: "Mariano Rivera", mvpTeam: "New York Yankees" },
      { year: 1998, winner: "New York Yankees", loser: "San Diego Padres", gamesWon: 4, gamesLost: 0, mvp: "Scott Brosius", mvpTeam: "New York Yankees" },
      { year: 1997, winner: "Florida Marlins", loser: "Cleveland Indians", gamesWon: 4, gamesLost: 3, mvp: "Liván Hernández", mvpTeam: "Florida Marlins" },
      { year: 1996, winner: "New York Yankees", loser: "Atlanta Braves", gamesWon: 4, gamesLost: 2, mvp: "John Wetteland", mvpTeam: "New York Yankees" },
      { year: 1995, winner: "Atlanta Braves", loser: "Cleveland Indians", gamesWon: 4, gamesLost: 2, mvp: "Tom Glavine", mvpTeam: "Atlanta Braves" },
      { year: 1993, winner: "Toronto Blue Jays", loser: "Philadelphia Phillies", gamesWon: 4, gamesLost: 2, mvp: "Paul Molitor", mvpTeam: "Toronto Blue Jays" },
      { year: 1992, winner: "Toronto Blue Jays", loser: "Atlanta Braves", gamesWon: 4, gamesLost: 2, mvp: "Pat Borders", mvpTeam: "Toronto Blue Jays" },
      { year: 1991, winner: "Minnesota Twins", loser: "Atlanta Braves", gamesWon: 4, gamesLost: 3, mvp: "Jack Morris", mvpTeam: "Minnesota Twins" },
      { year: 1990, winner: "Cincinnati Reds", loser: "Oakland Athletics", gamesWon: 4, gamesLost: 0, mvp: "José Rijo", mvpTeam: "Cincinnati Reds" },
      { year: 1989, winner: "Oakland Athletics", loser: "San Francisco Giants", gamesWon: 4, gamesLost: 0, mvp: "Dave Stewart", mvpTeam: "Oakland Athletics" },
      { year: 1988, winner: "Los Angeles Dodgers", loser: "Oakland Athletics", gamesWon: 4, gamesLost: 1, mvp: "Orel Hershiser", mvpTeam: "Los Angeles Dodgers" },
      { year: 1987, winner: "Minnesota Twins", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 3, mvp: "Frank Viola", mvpTeam: "Minnesota Twins" },
      { year: 1986, winner: "New York Mets", loser: "Boston Red Sox", gamesWon: 4, gamesLost: 3, mvp: "Ray Knight", mvpTeam: "New York Mets" },
      { year: 1985, winner: "Kansas City Royals", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 3, mvp: "Bret Saberhagen", mvpTeam: "Kansas City Royals" },
      { year: 1984, winner: "Detroit Tigers", loser: "San Diego Padres", gamesWon: 4, gamesLost: 1, mvp: "Alan Trammell", mvpTeam: "Detroit Tigers" },
      { year: 1983, winner: "Baltimore Orioles", loser: "Philadelphia Phillies", gamesWon: 4, gamesLost: 1, mvp: "Rick Dempsey", mvpTeam: "Baltimore Orioles" },
      { year: 1982, winner: "St. Louis Cardinals", loser: "Milwaukee Brewers", gamesWon: 4, gamesLost: 3, mvp: "Darrell Porter", mvpTeam: "St. Louis Cardinals" },
      { year: 1981, winner: "Los Angeles Dodgers", loser: "New York Yankees", gamesWon: 4, gamesLost: 2, mvp: "Ron Cey", mvpTeam: "Los Angeles Dodgers" },
      { year: 1980, winner: "Philadelphia Phillies", loser: "Kansas City Royals", gamesWon: 4, gamesLost: 2, mvp: "Mike Schmidt", mvpTeam: "Philadelphia Phillies" },
      { year: 1979, winner: "Pittsburgh Pirates", loser: "Baltimore Orioles", gamesWon: 4, gamesLost: 3, mvp: "Willie Stargell", mvpTeam: "Pittsburgh Pirates" },
      { year: 1978, winner: "New York Yankees", loser: "Los Angeles Dodgers", gamesWon: 4, gamesLost: 2, mvp: "Bucky Dent", mvpTeam: "New York Yankees" },
      { year: 1977, winner: "New York Yankees", loser: "Los Angeles Dodgers", gamesWon: 4, gamesLost: 2, mvp: "Reggie Jackson", mvpTeam: "New York Yankees" },
      { year: 1976, winner: "Cincinnati Reds", loser: "New York Yankees", gamesWon: 4, gamesLost: 0, mvp: "Johnny Bench", mvpTeam: "Cincinnati Reds" },
      { year: 1975, winner: "Cincinnati Reds", loser: "Boston Red Sox", gamesWon: 4, gamesLost: 3, mvp: "Pete Rose", mvpTeam: "Cincinnati Reds" },
      { year: 1974, winner: "Oakland Athletics", loser: "Los Angeles Dodgers", gamesWon: 4, gamesLost: 1, mvp: "Rollie Fingers", mvpTeam: "Oakland Athletics" },
      { year: 1973, winner: "Oakland Athletics", loser: "New York Mets", gamesWon: 4, gamesLost: 3, mvp: "Reggie Jackson", mvpTeam: "Oakland Athletics" },
      { year: 1972, winner: "Oakland Athletics", loser: "Cincinnati Reds", gamesWon: 4, gamesLost: 3, mvp: "Gene Tenace", mvpTeam: "Oakland Athletics" },
      { year: 1971, winner: "Pittsburgh Pirates", loser: "Baltimore Orioles", gamesWon: 4, gamesLost: 3, mvp: "Roberto Clemente", mvpTeam: "Pittsburgh Pirates" },
      { year: 1970, winner: "Baltimore Orioles", loser: "Cincinnati Reds", gamesWon: 4, gamesLost: 1, mvp: "Brooks Robinson", mvpTeam: "Baltimore Orioles" },
      { year: 1969, winner: "New York Mets", loser: "Baltimore Orioles", gamesWon: 4, gamesLost: 1, mvp: "Donn Clendenon", mvpTeam: "New York Mets" },
      { year: 1968, winner: "Detroit Tigers", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 3, mvp: "Mickey Lolich", mvpTeam: "Detroit Tigers" },
      { year: 1967, winner: "St. Louis Cardinals", loser: "Boston Red Sox", gamesWon: 4, gamesLost: 3, mvp: "Bob Gibson", mvpTeam: "St. Louis Cardinals" },
      { year: 1966, winner: "Baltimore Orioles", loser: "Los Angeles Dodgers", gamesWon: 4, gamesLost: 0, mvp: "Frank Robinson", mvpTeam: "Baltimore Orioles" },
      { year: 1965, winner: "Los Angeles Dodgers", loser: "Minnesota Twins", gamesWon: 4, gamesLost: 3, mvp: "Sandy Koufax", mvpTeam: "Los Angeles Dodgers" },
      { year: 1964, winner: "St. Louis Cardinals", loser: "New York Yankees", gamesWon: 4, gamesLost: 3, mvp: "Bob Gibson", mvpTeam: "St. Louis Cardinals" },
      { year: 1963, winner: "Los Angeles Dodgers", loser: "New York Yankees", gamesWon: 4, gamesLost: 0, mvp: "Sandy Koufax", mvpTeam: "Los Angeles Dodgers" },
      { year: 1962, winner: "New York Yankees", loser: "San Francisco Giants", gamesWon: 4, gamesLost: 3, mvp: "Ralph Terry", mvpTeam: "New York Yankees" },
      { year: 1961, winner: "New York Yankees", loser: "Cincinnati Reds", gamesWon: 4, gamesLost: 1, mvp: "Whitey Ford", mvpTeam: "New York Yankees" },
      { year: 1960, winner: "Pittsburgh Pirates", loser: "New York Yankees", gamesWon: 4, gamesLost: 3, mvp: "Bobby Richardson", mvpTeam: "New York Yankees" },
      { year: 1959, winner: "Los Angeles Dodgers", loser: "Chicago White Sox", gamesWon: 4, gamesLost: 2, mvp: "Larry Sherry", mvpTeam: "Los Angeles Dodgers" },
      { year: 1958, winner: "New York Yankees", loser: "Milwaukee Braves", gamesWon: 4, gamesLost: 3, mvp: "Bob Turley", mvpTeam: "New York Yankees" },
      { year: 1957, winner: "Milwaukee Braves", loser: "New York Yankees", gamesWon: 4, gamesLost: 3, mvp: "Lew Burdette", mvpTeam: "Milwaukee Braves" },
      { year: 1956, winner: "New York Yankees", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 3, mvp: "Don Larsen", mvpTeam: "New York Yankees" },
      { year: 1955, winner: "Brooklyn Dodgers", loser: "New York Yankees", gamesWon: 4, gamesLost: 3, mvp: "Johnny Podres", mvpTeam: "Brooklyn Dodgers" },
      { year: 1954, winner: "New York Giants", loser: "Cleveland Indians", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1953, winner: "New York Yankees", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1952, winner: "New York Yankees", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1951, winner: "New York Yankees", loser: "New York Giants", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1950, winner: "New York Yankees", loser: "Philadelphia Phillies", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1949, winner: "New York Yankees", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1948, winner: "Cleveland Indians", loser: "Boston Braves", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1947, winner: "New York Yankees", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1946, winner: "St. Louis Cardinals", loser: "Boston Red Sox", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1945, winner: "Detroit Tigers", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1944, winner: "St. Louis Cardinals", loser: "St. Louis Browns", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1943, winner: "New York Yankees", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1942, winner: "St. Louis Cardinals", loser: "New York Yankees", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1941, winner: "New York Yankees", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1940, winner: "Cincinnati Reds", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1939, winner: "New York Yankees", loser: "Cincinnati Reds", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1938, winner: "New York Yankees", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1937, winner: "New York Yankees", loser: "New York Giants", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1936, winner: "New York Yankees", loser: "New York Giants", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1935, winner: "Detroit Tigers", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1934, winner: "St. Louis Cardinals", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1933, winner: "New York Giants", loser: "Washington Senators", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1932, winner: "New York Yankees", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1931, winner: "St. Louis Cardinals", loser: "Philadelphia Athletics", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1930, winner: "Philadelphia Athletics", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1929, winner: "Philadelphia Athletics", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1928, winner: "New York Yankees", loser: "St. Louis Cardinals", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1927, winner: "New York Yankees", loser: "Pittsburgh Pirates", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1926, winner: "St. Louis Cardinals", loser: "New York Yankees", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1925, winner: "Pittsburgh Pirates", loser: "Washington Senators", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1924, winner: "Washington Senators", loser: "New York Giants", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1923, winner: "New York Yankees", loser: "New York Giants", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1922, winner: "New York Giants", loser: "New York Yankees", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1921, winner: "New York Giants", loser: "New York Yankees", gamesWon: 5, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1920, winner: "Cleveland Indians", loser: "Brooklyn Dodgers", gamesWon: 5, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1919, winner: "Cincinnati Reds", loser: "Chicago White Sox", gamesWon: 5, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1918, winner: "Boston Red Sox", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1917, winner: "Chicago White Sox", loser: "New York Giants", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1916, winner: "Boston Red Sox", loser: "Brooklyn Dodgers", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1915, winner: "Boston Red Sox", loser: "Philadelphia Phillies", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1914, winner: "Boston Braves", loser: "Philadelphia Athletics", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1913, winner: "Philadelphia Athletics", loser: "New York Giants", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1912, winner: "Boston Red Sox", loser: "New York Giants", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1911, winner: "Philadelphia Athletics", loser: "New York Giants", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1910, winner: "Philadelphia Athletics", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1909, winner: "Pittsburgh Pirates", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 3, mvp: null, mvpTeam: null },
      { year: 1908, winner: "Chicago Cubs", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1907, winner: "Chicago Cubs", loser: "Detroit Tigers", gamesWon: 4, gamesLost: 0, mvp: null, mvpTeam: null },
      { year: 1906, winner: "Chicago White Sox", loser: "Chicago Cubs", gamesWon: 4, gamesLost: 2, mvp: null, mvpTeam: null },
      { year: 1905, winner: "New York Giants", loser: "Philadelphia Athletics", gamesWon: 4, gamesLost: 1, mvp: null, mvpTeam: null },
      { year: 1903, winner: "Boston Red Sox", loser: "Pittsburgh Pirates", gamesWon: 5, gamesLost: 3, mvp: null, mvpTeam: null },
    ];

    seriesData.forEach((s) => {
      const id = randomUUID();
      this.worldSeries.set(id, { ...s, id });
    });

    const teamWins = seriesData.reduce((acc, s) => {
      acc[s.winner] = acc[s.winner] || [];
      acc[s.winner].push(s.year.toString());
      return acc;
    }, {} as Record<string, string[]>);

    Object.entries(teamWins).forEach(([name, years]) => {
      const id = randomUUID();
      this.teams.set(id, {
        id,
        name,
        championships: years.length,
        yearsWon: years,
      });
    });

    const momentsData: Omit<NotableMoment, "id">[] = [
      {
        year: 2016,
        title: "Cubs Break 108-Year Curse",
        description: "The Chicago Cubs defeated the Cleveland Indians in a thrilling 7-game series, ending their 108-year championship drought in one of baseball's greatest moments.",
        category: "Historic Victory",
      },
      {
        year: 2004,
        title: "Red Sox End 86-Year Curse",
        description: "Boston Red Sox swept the St. Louis Cardinals to win their first championship since 1918, breaking the legendary 'Curse of the Bambino.'",
        category: "Historic Victory",
      },
      {
        year: 1956,
        title: "Don Larsen's Perfect Game",
        description: "Don Larsen pitched the only perfect game in World Series history, defeating the Brooklyn Dodgers 2-0 in Game 5.",
        category: "Record Performance",
      },
      {
        year: 1977,
        title: "Reggie Jackson's Three Home Runs",
        description: "Reggie Jackson earned the nickname 'Mr. October' by hitting three consecutive home runs on three consecutive pitches in Game 6.",
        category: "Record Performance",
      },
      {
        year: 1988,
        title: "Kirk Gibson's Walk-Off Homer",
        description: "Kirk Gibson, hobbled by injuries, hit a dramatic pinch-hit walk-off home run in Game 1 to spark the Dodgers' championship run.",
        category: "Legendary Moment",
      },
      {
        year: 1991,
        title: "Greatest World Series Ever",
        description: "The Minnesota Twins defeated the Atlanta Braves in an epic 7-game series, with five games decided by one run and three going to extra innings.",
        category: "Classic Series",
      },
    ];

    momentsData.forEach((m) => {
      const id = randomUUID();
      this.notableMoments.set(id, { ...m, id });
    });
  }

  async getAllWorldSeries(): Promise<WorldSeries[]> {
    return Array.from(this.worldSeries.values());
  }

  async getAllTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }

  async getAllNotableMoments(): Promise<NotableMoment[]> {
    return Array.from(this.notableMoments.values());
  }
}

export const storage = new MemStorage();
