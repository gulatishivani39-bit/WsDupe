import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/world-series", async (_req, res) => {
    try {
      const series = await storage.getAllWorldSeries();
      res.json(series);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch World Series data" });
    }
  });

  app.get("/api/teams", async (_req, res) => {
    try {
      const teams = await storage.getAllTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch teams data" });
    }
  });

  app.get("/api/moments", async (_req, res) => {
    try {
      const moments = await storage.getAllNotableMoments();
      res.json(moments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notable moments data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
